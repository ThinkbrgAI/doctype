DocType Classifier
=================

This program helps organize construction documents by automatically classifying them into appropriate categories.

Features:
- Automatic document classification
- Batch processing
- Excel report generation
- Organized file output

For installation instructions, see INSTALLATION.txt

Version: 1.0
Last Updated: [current date] 